MET CS601: Module 1 Assignment
Qiuting Zhao
11/05/2024

Use w3schools html to searching for some functionalities and approaches.
Ask chatGPT to solve some coding problems I encountered, like the display = none operation also hide the success message.